
import { Route, Routes } from 'react-router'
import TopNavigationBar from "../TopNavigationBar/TopNavigationBar"
import SideNavigationBar from "../SideNavigationBar/SideNavigationBar"
import Dashboard from "../../pages/Dashboard/DashBoard"
import "./LoggedInStudent.css"
import { addStudentExams, changeStudentLiveExams, useGetStudentExamsQuery, useGetStudentLiveExamsQuery } from '../../../GlobalStore/GlobalStore'
import { useDispatch, useSelector } from 'react-redux'
import { useEffect } from 'react'
import { toast } from 'react-toastify'

function LoggedInStudent() {

    const dispatch = useDispatch()
    const config = useSelector((state) => state.config)

    const getLiveExamsResponse = useGetStudentLiveExamsQuery({ token: config.token })
    // const getOverAllStatisticsResponse = useGetStudentOverAllStatisticsQuery({ token: config.token })
    const getStudentExamsResponse = useGetStudentExamsQuery({ token: config.token, page: 1 })

    // const getRoomResponse = useGetStudentRoomQuery({ token: config.token })


    // useEffect(() => {
    //     if (!getRoomResponse.isLoading && !getRoomResponse.isUninitialized) {
    //         if (getRoomResponse.isError) {
    //             toast.error("Error loading room", { delay: 7 })
    //         } else {
    //             dispatch(changeRoom(getRoomResponse.data))
    //         }
    //     }
    // }, [getRoomResponse])



    useEffect(() => {
        if (!getLiveExamsResponse.isLoading && !getLiveExamsResponse.isUninitialized) {
            if (getLiveExamsResponse.isError) {
                toast.error("Error loading upcoming exams", { delay: 7 })
            } else {
                dispatch(changeStudentLiveExams(getLiveExamsResponse.data))
            }
        }
    }, [getLiveExamsResponse])

    // useEffect(() => {
    //     if (!getOverAllStatisticsResponse.isLoading && !getOverAllStatisticsResponse.isUninitialized) {
    //         if (getOverAllStatisticsResponse.isError) {
    //             toast.error("Error loading statistics", { delay: 7 })
    //         } else {
    //             dispatch(changeOverview(getOverAllStatisticsResponse.data))
    //         }
    //     }
    // }, [getOverAllStatisticsResponse])

    useEffect(() => {
        if (!getStudentExamsResponse.isLoading && !getStudentExamsResponse.isUninitialized) {
            if (getStudentExamsResponse.isError) {
                toast.error("Error loading exams", { delay: 7 })
            } else {
                dispatch(addStudentExams(getStudentExamsResponse.data))
            }
        }
    }, [getStudentExamsResponse])

    return <div className='logged-in-student-container'>
        <Routes>
            <Route path='/dashboard' element={<>
                <TopNavigationBar />
                <SideNavigationBar />
                <Dashboard />
            </>} />

            {/* <Route path='/enroll-exam' element={<>
                <TopNavigationBar />
                <SideNavigationBar />
                <Dashboard />
            </>} />

            <Route path='/exams-review' element={<>
                <TopNavigationBar />
                <SideNavigationBar />
                <Dashboard />
            </>} />

            <Route path='/exams-analysis' element={<>
                <TopNavigationBar />
                <SideNavigationBar />
                <Dashboard />
            </>} /> */}
        </Routes>
    </div>
}
export default LoggedInStudent