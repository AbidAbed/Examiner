import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

const StudentExamsAPI = createApi({
    reducerPath: "/student/exams",
    baseQuery: fetchBaseQuery({ baseUrl: process.env.REACT_APP_BACKEND_URL }),
    endpoints(builder) {
        return {
            getStudentExams: builder.query({
                query: (data) => {
                    return {
                        method: 'GET',
                        url: "/student/exams",
                        params: { page: data.page },
                        headers: { 'authentication': data.token }
                    }
                }
            }),
            getStudentLiveExams: builder.query({
                query: (data) => {
                    return {
                        method: "GET",
                        url: "/student/exams/live",
                        headers: { 'authentication': data.token }
                    }
                }
            }),
        }
    }
})

const {
    useGetStudentExamsQuery,
    useLazyGetStudentExamsQuery,
    useGetStudentLiveExamsQuery,
} = StudentExamsAPI
export {
    StudentExamsAPI,
    useGetStudentExamsQuery,
    useLazyGetStudentExamsQuery,
    useGetStudentLiveExamsQuery,
}