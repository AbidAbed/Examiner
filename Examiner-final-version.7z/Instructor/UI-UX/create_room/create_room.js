// create room pop up window
function openCreateRoomPopup() {
    document.getElementById('createRoomPopup').style.display = 'flex'; // Show popup
}

function closeCreateRoomPopup() {
    document.getElementById('createRoomPopup').style.display = 'none'; // Hide popup
}

// create room pop up window
